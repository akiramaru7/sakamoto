// JavaScript Document

(function( $ ) {
	$('.myColorPicker').wpColorPicker();
})( jQuery );